import React from 'react';

function OnlineStore() {
  return (
    <div style={{backgroundColor:"#9DBDFF"}} className="container responsive-container bg-orange-500">
      <div className="content text-center font-bold ">
        <h1 className="text-6xl text-[#A02334] mt-10 underline">Coming Soon...!</h1>
      </div>
    </div>
  );
}

export default OnlineStore;

