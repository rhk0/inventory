// MONGO_URI = mongodb+srv://manasvitech01:manasvitech01@cluster0.msglga2.mongodb.net/account
// PORT = 5000
// DEV_MODE = development
// JWT_SECRET = dharmapkdkhackerzonecommit 
// EMAIL_USER = manasvistaff.dharma@gmail.com
// EMAIL_PASS = pbqu tgfp ojyu uzcv

// RAZORPAY_KEY_ID = rzp_live_BU7B9FdceljAOe
// RAZORPAY_SECRET = 0ntpgNsX8d6T62sNo5Oujcvq